# RUBSIM v1.3.20

RUBSIM is a static, retro pixel-art training simulator for Rubrik administrators. The game is in English and runs from `index.html` in a modern browser. It needs no build step or backend. Google Fonts is loaded when network access is available; the game falls back to monospace fonts.

## High Availability workflows

The HA Policy wizard has five screens: introduction, policy details, optional host selection, optional archival-location selection, and confirmation. The HA SLA Domain wizard has nine screens: introduction, object types, HA Policy, Retention Lock, Frequency and Retention, Archival and Replication, Archival Parameters, Replication Parameters, and Confirmation. The created policy and selected SLA settings are saved in game state and flow into the VMware-protection and failover missions.

On Replication Parameters, the local-storage retention slider defaults to the snapshot-retention duration selected earlier. Its range expands when that duration exceeds 30 days. The VMware workload screen lists the available configured SLA Domain(s) in an enabled dropdown and carries the selected domain into the workload assignment.

## Game scenes

After the player enters a name, the hallway shows nameplates over the player, boss, and office door. The “Walk to the door” floor caption is removed. Martin’s placard is raised above the conference-room plant. Arrow keys, A/D, scene clicks, movement buttons, and the door hotspot control the office and conference-room scenes.

All in-game wording uses **Rubrik High Availability**. The presentation and knowledge check follow the Rubrik Security Cloud User Guide. After VMware workloads are protected, the Godzilla scenario leads into the HA failover wizard. The ending then shows the player and boss standing face to face in the office, the boss’s grumpy warning, a dark screen with blinking eyes, and a final mission-complete screen.

Godzilla appears only in outdoor shots and stops in front of Data Center North. The roof sign is positioned over the building. The right-facing flame asset starts at Godzilla’s mouth and is not mirrored. The failover action popup is placed outside the scrollable policy table.

## v1.3.20 changes

- Added player, boss, and office-door nameplates; removed the hallway floor prompt.
- Raised Martin’s conference-room placard above the plant.
- Linked local-retention slider defaults and range to the selected snapshot retention.
- Enabled the VMware SLA selector and populated it from available simulator domains.
- Renamed in-game Flexmotion HA wording to Rubrik High Availability.
- Added the grumpy office exchange, blinking-eyes scene, and mission-complete ending.

## Verification

- `node --check game.js` passes.
- `index.html` is non-empty; referenced local assets are present.
- Build version/cache values match v1.3.20.
- ZIP archive integrity and exact packaged file list were checked.
- Browser visual and interaction checks were not completed. The local file preview was blocked by browser policy, and the local HTTP preview needed a permission request that was cancelled.

## Install on the Ubuntu/Nginx host

Back up the current site, extract the ZIP, and copy the files into `/var/www/rubsim/`:

```sh
sudo cp -a /var/www/rubsim "/var/www/rubsim.backup.$(date +%Y%m%d-%H%M%S)"
unzip rubsim-v1.3.20.zip -d /tmp/rubsim-release
sudo cp -a /tmp/rubsim-release/rubsim-v1.3.20/. /var/www/rubsim/
```

Then open the game URL and hard-refresh. The Ubuntu host details in the handoff were not independently verified, and no deployment was performed.
