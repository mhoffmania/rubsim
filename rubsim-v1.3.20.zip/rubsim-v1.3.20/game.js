(() => {
  const $ = (selector) => document.querySelector(selector);
  const screen = $('#screen');
  const VERSION = '1.3.20';
  const savedVersion = localStorage.rubsim_version;
  if (savedVersion !== VERSION) {
    ['rubsim_failover_stage','rubsim_failover_event','rubsim_failover_acknowledged','rubsim_step','rubsim_operator','rubsim_upgraded','rubsim_policy','rubsim_sla','rubsim_policy_page','rubsim_sla_page','rubsim_presentation_page','rubsim_quiz_index','rubsim_quiz_score','rubsim_quiz_answers','rubsim_quiz_attempts','rubsim_failover_stage','rubsim_failover_event','rubsim_failover_acknowledged','rubsim_ending_stage'].forEach(k => localStorage.removeItem(k));
  }
  localStorage.rubsim_version = VERSION;
  const state = {
    step: localStorage.rubsim_step || 'intro', operator: localStorage.rubsim_operator || '',
    upgraded: JSON.parse(localStorage.rubsim_upgraded || '{}'),
    policy: JSON.parse(localStorage.rubsim_policy || 'null'),
    sla: JSON.parse(localStorage.rubsim_sla || 'null'),
    quizIndex:Number(localStorage.rubsim_quiz_index||0),quizScore:Number(localStorage.rubsim_quiz_score||0),
    quizAnswers:JSON.parse(localStorage.rubsim_quiz_answers||'[]'),quizAttempts:JSON.parse(localStorage.rubsim_quiz_attempts||'[]'),
    policyPage: Number(localStorage.rubsim_policy_page || 1), slaPage: Number(localStorage.rubsim_sla_page || 1),
    failoverStage:localStorage.rubsim_failover_stage||'policy',failoverEvent:Number(localStorage.rubsim_failover_event||0),
    failoverAcknowledged:localStorage.rubsim_failover_acknowledged==='true',endingStage:localStorage.rubsim_ending_stage||'talk',ready: false, unlockContinue: false
  };
  const missions = [['intro','Arrive at the office'],['arrival','Meet the manager'],['conference','Conference room'],['quiz','HA knowledge check'],['release','Read Release Notes'],['upgrade','Upgrade clusters'],['policy','Create HA Policy'],['sla','Create HA SLA Domain'],['protect','Protect VMware VMs'],['disaster','Godzilla attack'],['failover','HA failover']];
  const persist = () => {
    localStorage.rubsim_step=state.step; localStorage.rubsim_operator=state.operator;
    localStorage.rubsim_upgraded=JSON.stringify(state.upgraded); localStorage.rubsim_policy=JSON.stringify(state.policy);
    localStorage.rubsim_sla=JSON.stringify(state.sla); localStorage.rubsim_policy_page=state.policyPage; localStorage.rubsim_sla_page=state.slaPage;
    localStorage.rubsim_quiz_index=state.quizIndex;localStorage.rubsim_quiz_score=state.quizScore;localStorage.rubsim_quiz_answers=JSON.stringify(state.quizAnswers);localStorage.rubsim_quiz_attempts=JSON.stringify(state.quizAttempts);
    localStorage.rubsim_failover_stage=state.failoverStage;localStorage.rubsim_failover_event=state.failoverEvent;localStorage.rubsim_failover_acknowledged=String(state.failoverAcknowledged);localStorage.rubsim_ending_stage=state.endingStage;
  };
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function chrome(title, eyebrow='MISSION CONTROL') {
    $('#screen-title').textContent=title; $('#eyebrow').textContent=eyebrow;
    $('#operator-label').textContent=`OPERATOR: ${state.operator || 'TRAINEE'}`;
    $('#mood').textContent=state.step==='done'?'MANAGER: IMPRESSED':'MANAGER: GRUMPY'; renderMissions();
  }
  function renderMissions() {
    const active=missions.findIndex(m=>m[0]===state.step);
    $('#mission-list').innerHTML=missions.map((m,i)=>`<li class="${i<active?'done':i===active?'active':''}"><span class="num">${i<active?'✓':String(i+1).padStart(2,'0')}</span>${m[1]}</li>`).join('');
  }
  function chef(message,mood='GRUMPY / IMPRESSED',unlockContinue=false) {
    $('#manager-text').textContent=message; $('#manager-mood').textContent=mood; $('#modal').classList.remove('hidden'); $('#app').inert=true; state.ready=false; state.unlockContinue=unlockContinue;
  }
  $('#restart').addEventListener('click',()=>{
    if(!window.confirm('Restart RUBSIM from the beginning? Saved game progress will be cleared.'))return;
    Object.keys(localStorage).filter(key=>key.startsWith('rubsim_')).forEach(key=>localStorage.removeItem(key));
    window.location.reload();
  });
  function error(message) {
    document.querySelector('.validation-error')?.remove(); const el=document.createElement('div');
    el.className='notice alert validation-error'; el.setAttribute('role','alert'); el.textContent=message;
    screen.insertBefore(el,screen.querySelector('.actions'));
  }
  $('#thanks').addEventListener('click',()=>{
    $('#modal').classList.add('hidden'); $('#app').inert=false; state.ready=true;
    document.querySelectorAll('[data-continue],#pnext,#snext,#incident').forEach(b=>{if(state.unlockContinue&&b.matches('[data-continue]'))b.disabled=false;b.classList.add('continue-ready');});
    const after=state.afterChef;state.afterChef=null;if(after)after();
  });
  const continueButton = (label='CONTINUE',enabled=false) => `<button class="btn primary ${state.ready?'continue-ready':''}" data-continue ${enabled||state.ready?'':'disabled'}>${label}</button>`;
  const selected = (name) => [...document.querySelectorAll(`input[name="${name}"]:checked`)].map(i=>i.value);
  let movePlayer=()=>{};
  document.addEventListener('keydown',event=>{
    if(!['arrival','conference'].includes(state.step))return;
    if(['ArrowRight','KeyD'].includes(event.code)){event.preventDefault();movePlayer(8);}
    else if(['ArrowLeft','KeyA'].includes(event.code)){event.preventDefault();movePlayer(-8);}
    else if(event.code==='Enter'||event.code==='Space'){event.preventDefault();document.querySelector('#walk-target')?.click();}
  });
  function intro() {
    chrome('A late start','OFFICE ADVENTURE');
    screen.innerHTML=`<div class="adventure-scene office-scene intro-scene" role="group" aria-label="Office hallway entrance. Enter your name before walking in."><div class="scene-shade"></div><div class="scene-sign">RUBSIM · OPERATIONS FLOOR</div><div class="scene-caption"><b>MONDAY · 09:17 AM</b><span>The hallway is quiet. Someone is waiting by the office door.</span></div><div class="name-card"><label for="operator">YOUR NAME</label><input id="operator" placeholder="e.g. Alex" value="${esc(state.operator)}"><button class="btn primary" id="start">START SHIFT</button></div></div><p class="subtle">Use the arrow keys, A/D, the screen, or the movement buttons to explore.</p>`;
    $('#start').onclick=()=>{state.operator=$('#operator').value.trim()||'Operator';state.step='arrival';persist();arrival();};
  }
  function playerMarkup(){return `<div class="player-sprite" id="player-sprite"><img src="assets/player-pixel.png" alt="${esc(state.operator||'Player')} walking through the office hallway"><span class="actor-nameplate">${esc(state.operator||'Player')}</span></div>`;}
  function adventureRoom(kind,title,hint,targetLabel,targetX,onArrive){
    const office=kind==='office';state.step=office?'arrival':'conference';chrome(title,office?'OFFICE ADVENTURE':'CONFERENCE ROOM');state.playerX=6;
    const startX=office?6:66;
    state.playerX=startX;
    screen.innerHTML=`<div class="adventure-scene ${office?'office-scene':'conference-scene'}" id="adventure-scene" tabindex="0" role="application" aria-label="${office?'Office hallway':'Conference room'}; use arrow keys or A and D to move"><div class="scene-shade"></div>${office?'<button type="button" class="scene-door-hotspot" id="door-hotspot" aria-label="Walk to the office doorway"><span>OFFICE DOOR</span></button>':'<div class="conference-board"><span>RUBRIK SECURITY CLOUD</span><b>HIGH AVAILABILITY</b><small>RUBRIK HIGH AVAILABILITY · KNOWLEDGE CHECK</small></div>'}<div class="scene-sign">${office?'RUBSIM · OPERATIONS FLOOR':'CONFERENCE ROOM · 2B'}</div><div class="scene-caption"><b>${office?'09:17 AM · YOU ARE RUNNING LATE':'MEETING IN PROGRESS'}</b><span>${hint}</span></div>${office?`<figure class="manager-marker"><img src="assets/manager-full-pixel.png" alt="Grumpy manager waiting at the office doorway"><figcaption>THE BOSS</figcaption></figure>`:`<div class="conference-poster"><img src="assets/martin-pixel.png" alt="Martin, Sales Engineer at Rubrik"><div><b>MARTIN · SALES ENGINEER</b><span>Rubrik High Availability presentation</span></div></div>`}${playerMarkup()}${office?'':'<div class="move-tip">WALK TO THE TABLE</div>'}</div><div class="adventure-controls"><span>MOVE</span><button class="btn move-left" aria-label="Move left">◀</button><button class="btn move-right" aria-label="Move right">▶</button><button class="btn primary" id="walk-target">${targetLabel}</button><span class="control-hint">← → / A D · CLICK WALKABLE FLOOR</span></div>`;
    let busy=false;const player=$('#player-sprite'),scene=$('#adventure-scene');
    const walkTo=(x,finish=false)=>{if(busy)return;const next=Math.max(4,Math.min(office?82:82,x));if(Math.abs(next-state.playerX)<1){if(finish)onArrive();return;}const from=state.playerX,distance=Math.abs(next-from),duration=Math.max(280,distance*18);busy=true;player.classList.toggle('facing-left',next<from);player.classList.add('walking');player.style.left=`${next}%`;window.setTimeout(()=>{player.classList.remove('walking');busy=false;state.playerX=next;if(finish)onArrive();},duration);};
    const arrive=()=>walkTo(targetX,true);
    const move=(delta)=>{const next=state.playerX+delta;if(office&&next>=targetX)return walkTo(targetX,true);walkTo(next,false);};
    movePlayer=move;$('#walk-target').onclick=arrive;$('#door-hotspot')?.addEventListener('click',arrive);$('.move-left').onclick=()=>move(-8);$('.move-right').onclick=()=>move(8);
    scene.addEventListener('click',event=>{scene.focus();if(event.target.closest('button'))return;const rect=scene.getBoundingClientRect(),x=Math.round((event.clientX-rect.left)/rect.width*100),finish=office&&x>=targetX;walkTo(finish?targetX:x,finish);});
    scene.focus();
  }
  function arrival(){
    adventureRoom('office','At the office',`There he is. Walk over before he sees you standing around.`,`WALK TO THE DOOR`,59,()=>{state.afterChef=conference;chef(`You’re late, ${state.operator}. Rubrik’s High Availability presentation is already over. I asked Martin to stay and quiz you, to make sure you know something about High Availability. Head to the conference room.`,'GRUMPY');});
    chef('09:17 AM · YOU ARE RUNNING LATE\n\nThere he is. Walk over before he sees you standing around.','GRUMPY');
  }
  function conference(){
    adventureRoom('conference','Conference room',`The presentation is over. Take a seat for the High Availability knowledge check.`,`TAKE YOUR SEAT`,42,beginQuiz);
  }
  const haQuestions=[
    {recap:'A cluster outage can interrupt backup and recovery operations.',ask:'What problem does High Availability address?',options:['It automatically restarts every protected production application.','It lets the secondary cluster take over backup and archival operations after a manual failover.','It removes the need to replicate backup data.'],answer:1,why:'HA preserves continuity of backup data and operations. Failover transfers the Rubrik cluster role; it is not the same as workload-level HA.'},
    {recap:'One primary. One secondary. A coordinated group.',ask:'What does an HA Policy define?',options:['A relationship between one primary and one secondary cluster for selected hosts, workloads, and archival locations.','A schedule that moves all Rubrik workloads between any number of clusters automatically.','A VMware-only policy for restarting virtual machines.'],answer:0,why:'An HA Policy groups hosts, protected workloads, and archival locations on a single primary-secondary cluster pair.'},
    {recap:'When the primary is available, a clean failover can wait for replication.',ask:'What happens during a clean failover?',options:['It immediately switches to the last replicated snapshot without checking the primary.','It pauses primary backups and waits for pending snapshots to replicate before completing the transition.','It automatically fails over when a health check fails.'],answer:1,why:'Clean failover is graceful: backups pause on the primary and pending snapshots are allowed to replicate before the role transfer.'},
    {recap:'A forced failover is for when the primary cluster is unavailable.',ask:'What is the main recovery risk of forced failover?',options:['It waits for all snapshots to replicate, so it takes longer.','It restores only a new full backup.','It uses the latest data available on the secondary, so unreplicated snapshots may be missing.'],answer:2,why:'Forced failover does not wait for replication. Any snapshot that had not reached the secondary is unavailable there until the primary returns.'},
    {recap:'Preparation matters: both clusters, their links, hosts, and archives must be ready.',ask:'Which setup is consistent with the HA prerequisites?',options:['CDM 9.6+ on both RSC-managed clusters, bidirectional replication, and shared workload prerequisites configured.','A single cluster on CDM 9.6 with automatic failover enabled.','Any two clusters, with replication in one direction only.'],answer:0,why:'The guide requires both clusters on CDM 9.6+ and managed by RSC, bidirectional replication, and account enablement. VMware uses the same vCenter on both; RBS registers host-based workloads to both clusters.',source:'RUBRIK SECURITY CLOUD USER GUIDE · OCT 05, 2026'}
  ];
  function beginQuiz(){state.step='quiz';state.quizIndex=0;state.quizScore=0;state.quizAnswers=[];state.quizAttempts=[];persist();renderQuiz();}
  function renderQuiz(){
    state.step='quiz';chrome('The HA knowledge check','CONFERENCE ROOM');
    if(state.quizIndex>=haQuestions.length){renderQuizResult();return;}
    const n=state.quizIndex,q=haQuestions[n],answer=state.quizAnswers[n],answered=answer!==undefined,correct=answered&&answer===q.answer;
    screen.innerHTML=`<div class="quiz-progress"><div class="step-dots">${haQuestions.map((_,i)=>`<span class="${i<=n?'on':''}"></span>`).join('')}</div><span>QUESTION ${n+1} OF 5</span></div><section class="quiz-room"><aside class="quiz-presenter"><div class="conference-mini-screen"><img src="assets/martin-pixel.png" alt="Martin presenting High Availability"><span>RUBRIK HIGH AVAILABILITY</span></div><div class="presenter-caption"><b>MARTIN</b><span>SALES ENGINEER · RUBRIK</span></div><blockquote>${q.recap}</blockquote><small>${q.source||'RUBRIK SECURITY CLOUD USER GUIDE · HIGH AVAILABILITY'}</small></aside><article class="quiz-question"><div class="eyebrow">${n===4?'PREREQUISITES':'HIGH AVAILABILITY · CONCEPT CHECK'}</div><h2>${q.ask}</h2><div class="quiz-options">${q.options.map((opt,i)=>`<label class="quiz-option ${answered&&i===q.answer?'answer-correct':''} ${answered&&i===answer&&!correct?'answer-wrong':''}"><input type="radio" name="quiz-answer" value="${i}" ${answered&&i===answer?'checked':''} ${answered?'disabled':''}><span class="option-key">${String.fromCharCode(65+i)}</span><span>${opt}</span></label>`).join('')}</div>${answered?`<div class="quiz-feedback ${correct?'good':'needs-work'}"><b>${correct?'CORRECT':'NOT QUITE'}</b><p>${q.why}</p></div>`:''}<div class="actions">${answered?`<button class="btn primary" id="quiz-next">${n<4?'NEXT QUESTION':'SEE RESULTS'}</button>`:`<button class="btn primary" id="quiz-submit">SUBMIT ANSWER</button>`}</div></article></section>`;
    if(!answered){$('#quiz-submit').onclick=()=>{const chosen=document.querySelector('input[name="quiz-answer"]:checked');if(!chosen){error('Choose an answer before submitting.');return;}const selectedAnswer=Number(chosen.value);state.quizAnswers[n]=selectedAnswer;state.quizAttempts[n]=(state.quizAttempts[n]||0)+1;if(selectedAnswer===q.answer)state.quizScore++;persist();renderQuiz();};}
    else $('#quiz-next').onclick=()=>{state.quizIndex++;persist();renderQuiz();};
  }
  function renderQuizResult(){
    state.step='quiz';chrome('Knowledge check complete','CONFERENCE ROOM');
    const score=state.quizScore,grade=score===5?'IMPRESSIVE (RELUCTANTLY)':score>=3?'GOOD ENOUGH FOR A MONDAY':'ROOM FOR IMPROVEMENT';
    screen.innerHTML=`<section class="quiz-result"><div class="result-portrait"><img src="assets/martin-pixel.png" alt="Martin, Sales Engineer at Rubrik"></div><div><div class="eyebrow">FIVE QUESTIONS COMPLETE</div><h2>${score} / 5 correct on the first try</h2><p class="manager-mood">${grade}</p><p>You reviewed what HA protects, how HA Policies pair clusters, the difference between clean and forced failover, and the prerequisites to check before setup.</p><div class="quiz-review">${haQuestions.map((q,i)=>`<div class="review-row"><b>${i+1}. ${state.quizAnswers[i]===q.answer?'✓':'↻'}</b><span>${q.ask}</span></div>`).join('')}</div><button class="btn primary" id="quiz-finish">CONTINUE TO RELEASE NOTES</button></div></section>`;
    $('#quiz-finish').onclick=()=>{state.step='release';persist();releaseNotes();chef(`You made it through five questions, ${state.operator}. Now read the Rubrik 9.6 Release Notes before we upgrade the clusters. I’d prefer not to explain the obvious twice.`,'GRUMPY');};
  }
  function releaseNotes(){
    state.step='release';chrome('Read the Release Notes','BEFORE YOU UPGRADE');
    screen.innerHTML=`<div class="notice"><b>RUBRIK CDM 9.6 · RELEASE NOTES CHECK</b><br>Review the release information before starting the cluster upgrades.</div><article class="card release-card"><h3>WHAT TO KNOW</h3><ul><li>High Availability Policies are supported starting with CDM 9.6.</li><li>Both clusters in an HA pair must run CDM 9.6 or later and be managed by Rubrik Security Cloud.</li><li>Failover is a manual operation; automatic failover is not supported.</li></ul><p class="subtle">Source: Rubrik Security Cloud User Guide, “High Availability prerequisites” and “High Availability key concepts,” pages 311–312.</p></article><div class="actions"><button class="btn primary" id="read-release">I’VE READ THE RELEASE NOTES — START UPGRADE</button></div>`;
    $('#read-release').onclick=()=>{state.step='upgrade';persist();upgrade();chef('Good. Upgrade both clusters to CDM 9.6 before configuring Rubrik High Availability. Download the package first.','GRUMPY');};
  }
  function tone() {
    try { const ctx=new(window.AudioContext||window.webkitAudioContext)(),o=ctx.createOscillator(),g=ctx.createGain(); o.type='sine';o.frequency.value=880;g.gain.setValueAtTime(.001,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.12,ctx.currentTime+.03);g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+.5);o.connect(g);g.connect(ctx.destination);o.start();o.stop(ctx.currentTime+.5); } catch(e) {}
  }
  function upgrade() {
    chrome('Cluster software upgrades','CLUSTER MANAGEMENT'); const names=['North','South'];
    screen.innerHTML=`<div class="notice"><b>AVAILABLE RELEASE: 9.6</b><br>High Availability Policies are now supported. Upgrade both clusters from 9.5.2 before continuing.</div>
      <div class="grid">${names.map(n=>`<article class="card"><div class="cluster"><h3>${n} Cluster</h3><span class="tag ${state.upgraded[n]?'ok':''}" id="tag-${n}">${state.upgraded[n]?'UP TO DATE':'READY'}</span><div class="details"><span>Installed: <b id="ver-${n}">${state.upgraded[n]?'9.6':'9.5.2'}</b></span><span>Status: <b id="stat-${n}">${state.upgraded[n]?'Completed':'Healthy'}</b></span></div></div><div class="progress"><span id="bar-${n}" style="width:${state.upgraded[n]?'100%':'0%'}"></span></div><div class="actions"><button class="btn" id="pkg-${n}" ${state.upgraded[n]?'disabled':''}>DOWNLOAD PACKAGE</button><button class="btn primary" id="up-${n}" ${state.upgraded[n]?'disabled':''}>UPGRADE CLUSTER</button></div></article>`).join('')}</div>
      <div class="actions">${continueButton()}</div>`;
    names.forEach(n=>{
      let downloaded=false;
      $('#pkg-'+n).onclick=()=>{downloaded=true;$('#stat-'+n).textContent='Package downloaded';$('#tag-'+n).textContent='PACKAGE READY';};
      $('#up-'+n).onclick=()=>{
        if(!downloaded){$('#stat-'+n).textContent='Download package first';return;}
        const start=performance.now();$('#stat-'+n).textContent='Upgrading…';$('#up-'+n).disabled=true;
        const timer=setInterval(()=>{const p=Math.min(100,(performance.now()-start)/100);$('#bar-'+n).style.width=p+'%';if(p>=100){clearInterval(timer);state.upgraded[n]=true;persist();$('#ver-'+n).textContent='9.6';$('#stat-'+n).textContent='Completed';$('#tag-'+n).textContent='UP TO DATE';$('#tag-'+n).classList.add('ok');$('#pkg-'+n).disabled=true;$('#up-'+n).disabled=true;if(names.every(x=>state.upgraded[x])){tone();chef('Both clusters are on 9.6. Nobody called me for help. I am almost impressed.','GRUMPY / IMPRESSED',true);upgrade();}}},100);
      };
    });
    if(names.every(x=>state.upgraded[x])){const btn=screen.querySelector('[data-continue]');btn.disabled=false;btn.onclick=()=>{state.step='policy';state.policyPage=1;persist();chef('Both clusters are upgraded. Now create an HA Policy. Try not to make me regret delegating this.','IMPRESSED (RELUCTANTLY)');policy();};}
  }
  const hosts=[
    ['north-ad01-ec01.rubrikdemo.com','Connected','Windows'],['north-ad01.rubrikdemo.com','Connected','Windows'],['north-ad02.rubrikdemo.com','Connected','Windows'],
    ['north-addest01.rubrikdemo.com','Connected','Windows'],['north-addest02.rubrikdemo.com','Connected','Windows'],['north-fs-01.rubrikdemo.com','Connected','Linux'],
    ['north-fs-02.rubrikdemo.com','Connected','Linux'],['north-hv-w1.rubrikdemo.com','Connected','Windows'],['north-hv-w2.rubrikdemo.com','Connected','Windows'],
    ['north-hv-w3.rubrikdemo.com','Disconnected','Windows']
  ];
  const archives=[
    ['AWS:north-austin-archive','Amazon S3','Read and Write','north-austin-archive','N/A'],['Azure:north-austin-archive','Microsoft Azure','Read and Write','north-austin-container','N/A'],
    ['GCP:north-austin-archive','Google Cloud','Read and Write','north-austin-archive','N/A'],['RCV-Archive-AWS-North','Rubrik Cloud Vault','Read and Write','—','N/A'],
    ['RCV-Archive-Azure-North','Rubrik Cloud Storage','Read Only','—','N/A'],['RCV-Backup-AWS-North','Rubrik Cloud Vault','Paused','—','N/A'],
    ['RCV-Backup-Azure-North','Rubrik Cloud Storage','Read and Write','—','N/A'],['RCV-Backup-Immutable-North','Rubrik Cloud Storage','Read and Write','—','N/A']
  ];
  function policy() {
    chrome('Create an HA Policy','POLICY CONFIGURATION'); const p=state.policy||{}; const n=state.policyPage;
    const pages=[
      `<div class="notice"><b>WHAT’S A HIGH AVAILABILITY POLICY?</b><br>An HA Policy links hosts and archival locations to a source and target cluster. If the source is unavailable and failover is initiated, the target cluster is used to take backups.<br><br><b>HA POLICY DETAILS</b><br>Select a source and target cluster in a bi-directional replication pair.<br><br><b>SELECT HOSTS</b><br>Hosts must be registered on both selected clusters and have the RBS agent installed.<br><br><b>SELECT ARCHIVAL LOCATIONS</b><br>Archival locations must belong to the source cluster; the target cluster must be a reader.</div>`,
      `<div class="notice">Select a source and target cluster that are in a bi-directional replication pair. When a failover is initiated, the target cluster is used as the source.</div><div class="form-grid"><div class="field"><label>HA POLICY NAME *</label><input id="pname" placeholder="Enter a policy name" value="${esc(p.name)}"></div><div class="field"><label>DESCRIPTION <span class="muted">(optional)</span></label><input id="pdesc" placeholder="Enter a description" value="${esc(p.description)}"></div><div class="field"><label>SOURCE CLUSTER *</label><select id="source"><option value="">Select a cluster</option><option ${p.source==='North'?'selected':''}>North</option><option ${p.source==='South'?'selected':''}>South</option></select></div><div class="field"><label>TARGET CLUSTER *</label><select id="target"><option value="">Select a cluster</option><option ${p.target==='North'?'selected':''}>North</option><option ${p.target==='South'?'selected':''}>South</option></select></div></div>`,
      `<div class="subtle">Showing hosts whose RBS agent is registered to both selected clusters.</div><div class="filter-layout"><div class="filter-box"><h3>RBS STATUS</h3>${['All','Connected','Disconnected'].map(v=>`<label class="check-row"><input type="radio" name="rbs-filter" value="${v}" ${((p.hostFilters?.rbs||'Connected')===v)?'checked':''}> ${v}</label>`).join('')}<h3>HOST TYPE</h3>${['Linux','Windows'].map(v=>`<label class="check-row"><input type="checkbox" name="host-types" value="${v}" ${(p.hostFilters?.types||[]).includes(v)?'checked':''}> ${v}</label>`).join('')}</div><div class="table-wrap"><table><thead><tr><th><input id="hosts-all" type="checkbox" aria-label="Select all displayed hosts"></th><th>HOST / IP ADDRESS</th><th>RBS STATUS</th><th>OS TYPE</th></tr></thead><tbody id="host-rows"></tbody></table></div></div>`,
      `<div class="subtle">Select archival locations if you want to enable archival of hosts and objects included in the HA policy later. Only archival locations linked to the source cluster are shown. Make sure the target cluster is a reader cluster.</div><div class="filter-layout"><div class="filter-box"><label class="field"><input id="archive-search" placeholder="Search Storage Type"></label><h3>STORAGE TYPE</h3>${['Amazon S3','AWS DCA','AWS LCK','Microsoft Azure','Amazon Glacier','Google Cloud'].map(v=>`<label class="check-row"><input type="checkbox" name="storage-types" value="${v}" ${(p.archiveFilters?.types||[]).includes(v)?'checked':''}> ${v}</label>`).join('')}<h3>STATUS</h3>${['Read and Write','Read Only','Paused'].map(v=>`<label class="check-row"><input type="checkbox" name="archive-status" value="${v}" ${(p.archiveFilters?.status||[]).includes(v)?'checked':''}> ${v}</label>`).join('')}</div><div class="table-wrap"><table><thead><tr><th><input id="archives-all" type="checkbox" aria-label="Select all displayed archival locations"></th><th>ARCHIVAL LOCATION</th><th>STORAGE TYPE</th><th>STATUS</th><th>STORAGE LOCATION</th><th>IMMUTABILITY</th></tr></thead><tbody id="archive-rows"></tbody></table></div></div>`,
      `<div class="card"><h3>CONFIRMATION</h3><div class="summary"><b>HA Policy Name</b><span>${esc(p.name)||'—'}</span><b>Description</b><span>${esc(p.description)||'—'}</span><b>Source Cluster</b><span>${esc(p.source)||'—'}</span><b>Target Cluster</b><span>${esc(p.target)||'—'}</span><b>Hosts</b><span>${(p.hosts||[]).length} · ${(p.hosts||[]).map(esc).join(', ')||'None selected'}</span><b>Archival Locations</b><span>${(p.archives||[]).length} · ${(p.archives||[]).map(esc).join(', ')||'None selected'}</span></div></div>`
    ];
    screen.innerHTML=`<div class="step-dots">${pages.map((_,i)=>`<span class="${i<n?'on':''}"></span>`).join('')}</div><div class="subtle">STEP ${n} OF 5</div><div class="section-list"><article class="card"><h3>${['INTRODUCTION','HA POLICY DETAILS','SELECT HOSTS · OPTIONAL','SELECT ARCHIVAL LOCATIONS · OPTIONAL','CONFIRMATION'][n-1]}</h3>${pages[n-1]}</article></div><div class="actions"><button class="btn" id="pback" ${n===1?'disabled':''}>BACK</button>${n<5?'<button class="btn primary" id="pnext">NEXT</button>':continueButton('CREATE',true)}</div>`;
    const renderHosts=()=>{
      const rbs=document.querySelector('input[name="rbs-filter"]:checked')?.value||'Connected';const types=selected('host-types');
      const rows=hosts.map((h,i)=>({...h,index:i})).filter(h=>(rbs==='All'||h[1]===rbs)&&(!types.length||types.includes(h[2])));
      $('#host-rows').innerHTML=rows.map(h=>`<tr><td><input type="checkbox" name="host-selection" value="${esc(h[0])}" ${(p.hosts||[]).includes(h[0])?'checked':''}></td><td>${esc(h[0])}</td><td>${esc(h[1])}</td><td>${esc(h[2])}</td></tr>`).join('');
      document.querySelectorAll('[name="host-selection"]').forEach(el=>el.onchange=()=>{const visible=rows.map(h=>h[0]);p.hosts=[...(p.hosts||[]).filter(h=>!visible.includes(h)),...selected('host-selection')];state.policy=p;persist();});
      $('#hosts-all').onchange=()=>{document.querySelectorAll('input[name="host-selection"]').forEach(c=>c.checked=$('#hosts-all').checked);p.hosts=[...(p.hosts||[]).filter(h=>!rows.some(r=>r[0]===h)),...selected('host-selection')];state.policy=p;persist();};
    };
    const renderArchives=()=>{
      const types=selected('storage-types'),statuses=selected('archive-status'),search=$('#archive-search').value.toLowerCase();
      const rows=archives.filter(a=>(!types.length||types.includes(a[1]))&&(!statuses.length||statuses.includes(a[2]))&&a.join(' ').toLowerCase().includes(search));
      $('#archive-rows').innerHTML=rows.map(a=>`<tr><td><input type="checkbox" name="archive-selection" value="${esc(a[0])}" ${(p.archives||[]).includes(a[0])?'checked':''}></td>${a.map(x=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('');
      document.querySelectorAll('[name="archive-selection"]').forEach(el=>el.onchange=()=>{const visible=rows.map(a=>a[0]);p.archives=[...(p.archives||[]).filter(a=>!visible.includes(a)),...selected('archive-selection')];state.policy=p;persist();});
      $('#archives-all').onchange=()=>{document.querySelectorAll('input[name="archive-selection"]').forEach(c=>c.checked=$('#archives-all').checked);p.archives=[...(p.archives||[]).filter(a=>!rows.some(r=>r[0]===a[0])),...selected('archive-selection')];state.policy=p;persist();};
    };
    if(n===3){renderHosts();document.querySelectorAll('[name="rbs-filter"]').forEach(el=>el.onchange=()=>{p.hostFilters={...(p.hostFilters||{}),rbs:document.querySelector('[name="rbs-filter"]:checked')?.value||'Connected'};state.policy=p;persist();renderHosts();});document.querySelectorAll('[name="host-types"]').forEach(el=>el.onchange=()=>{p.hostFilters={...(p.hostFilters||{}),types:selected('host-types')};state.policy=p;persist();renderHosts();});}
    if(n===4){renderArchives();const refreshArchives=()=>{p.archiveFilters={types:selected('storage-types'),status:selected('archive-status')};state.policy=p;persist();renderArchives();};document.querySelectorAll('[name="storage-types"],[name="archive-status"]').forEach(el=>el.onchange=refreshArchives);$('#archive-search').oninput=renderArchives;}
    $('#pback').onclick=()=>{if(n===2)savePolicyInputs();state.policyPage=Math.max(1,n-1);persist();policy();};
    if(n<5)$('#pnext').onclick=()=>{
      if(n===2){savePolicyInputs();if(!state.policy.name||!state.policy.source||!state.policy.target){error('Complete the policy name, source cluster, and target cluster to continue.');return;}if(state.policy.source===state.policy.target){error('The source and target must be different clusters.');return;}}
      if(n===3)state.policy={...state.policy,hosts:state.policy.hosts||selected('host-selection'),hostFilters:{rbs:document.querySelector('[name="rbs-filter"]:checked')?.value||'Connected',types:selected('host-types')}};
      if(n===4)state.policy={...state.policy,archives:state.policy.archives||selected('archive-selection'),archiveFilters:{types:selected('storage-types'),status:selected('archive-status')}};
      state.policyPage=n+1;persist();policy();if(n>1)chef(({2:'HA Policy details saved. Next, choose hosts if you want to narrow the policy.',3:'Host selection saved. You may also leave the optional list empty.',4:'Archival locations saved. Check the source and target cluster roles.'})[n],'GRUMPY / IMPRESSED',n===4);
    };
    if(n===5){const c=screen.querySelector('[data-continue]');c.onclick=()=>{state.step='sla';state.slaPage=1;persist();chef(`HA Policy “${state.policy.name}” is created. I hope you remember what you named it.`,'IMPRESSED');sla();};}
  }
  function savePolicyInputs(){state.policy={...state.policy,name:$('#pname')?.value.trim()||'',description:$('#pdesc')?.value.trim()||'',source:$('#source')?.value||'',target:$('#target')?.value||''};}
  const slaPages=['INTRODUCTION','SELECT OBJECT TYPES','HA POLICY','RETENTION LOCK','FREQUENCY AND RETENTION','ARCHIVAL AND REPLICATION','ARCHIVAL PARAMETERS','REPLICATION PARAMETERS','CONFIRMATION'];
  function sla(){
    chrome('Create an HA SLA Domain','SLA DOMAIN CONFIGURATION');const x=state.sla||{},n=state.slaPage;
    const activeIntervals=(values,units={})=>Object.entries(values||{}).filter(([,v])=>Number(v)>0).map(([unit,v])=>`${v} ${units[unit]||unit}`).join(', ')||'None configured';
    const frequencySummary=activeIntervals(x.frequency);
    const retentionSummary=Object.entries(x.retention||{}).filter(([,v])=>Number(v)>0).map(([unit,v])=>`${v} ${x.retentionUnit?.[unit]||'days'} (for ${unit} snapshots)`).join(', ')||'None configured';
    const durationDays={days:1,weeks:7,months:30,years:365};
    const retentionDays=Math.max(0,...Object.entries(x.retention||{}).filter(([,v])=>Number(v)>0).map(([unit,v])=>Number(v)*(durationDays[x.retentionUnit?.[unit]||'days']||1)));
    const replicationMax=retentionDays||30;
    const replicationInitial=Math.min(Number(x.repRetention??retentionDays),replicationMax);
    const localRetentionMax=Math.max(30,retentionDays);
    const localRetentionInitial=Math.min(localRetentionMax,Math.max(0,Number(x.localRetentionForRetentionDays===retentionDays?x.localRetention:retentionDays)));
    const archiveDays=Number(x.archivalRetentionDays??0);
    const archiveYears=Math.floor(archiveDays/365),archiveRemainder=archiveDays%365;
    const policyHosts=[...new Set(state.policy?.hosts||[])];
    const archiveClusters=[...new Set([state.policy?.source,state.policy?.target].filter(Boolean))];
    const archiveOptions=[...new Set(state.policy?.archives||[])];
    const archiveSelections=x.archivalLocations||{};
    const archivePolicySummary=archiveClusters.map(cluster=>`${cluster}: ${archiveSelections[cluster]||'None selected'}`).join('; ')||'No clusters selected';
    const objectGroups=[['Virtual Machines',['vSphere VMs']],['Databases and Apps',['Microsoft SQL Server','Db2']],['Physical Hosts',['Filesets','Windows Volume']]];
    const content=[
      `<div class="notice"><b>WHAT ARE HA SLA DOMAINS?</b><br>An HA SLA Domain is linked to an HA Policy and assigned to objects that need continuous protection. HA SLA Domains define frequency, retention, and archival/replication settings for the protected objects.<br><br><b>THIS WORKFLOW</b><br>Select object types, map an HA Policy, configure retention and snapshot frequency, choose archival and replication options, then review the configuration.</div>`,
      `<div class="notice">Only object types supported by high availability are shown.</div><p>Select the types of objects you want to assign this SLA Domain to.</p>${objectGroups.map(([group,types])=>`<div class="object-group"><b>${group}</b><div class="object-options">${types.map(t=>`<label class="check-row"><input type="checkbox" name="objects" value="${t}" ${(x.objects||[]).includes(t)?'checked':''}> ${t}</label>`).join('')}</div></div>`).join('')}<label class="check-row"><input id="system-tags" type="checkbox" ${x.systemTags?'checked':''}> Assign SLA Domain to system tags</label>`,
      `<p>Select an HA policy to ensure objects protected by this SLA Domain are continuously protected.</p><div class="field"><label>HA POLICY *</label><select id="mapped"><option value="">Select HA Policy</option>${state.policy?`<option value="${esc(state.policy.name)}" ${x.mapped===state.policy.name?'selected':''}>${esc(state.policy.name)}</option>`:''}</select></div>${state.policy&&x.mapped===state.policy.name?`<div class="summary policy-pair"><b>Source Cluster</b><span>${esc(state.policy.source)}</span><b>Target Cluster</b><span>${esc(state.policy.target)}</span></div>`:''}`,
      `<div class="toggle-heading"><h3>RETENTION LOCK</h3><label class="switch"><input id="retention-lock" type="checkbox" ${x.retentionLock?'checked':''}><span></span></label></div><p>Prevent data from being accidentally or maliciously modified or deleted during the retention period.</p><p class="subtle">Retention Lock is optional. Once enabled, protected snapshots cannot be shortened or removed before retention expires.</p>`,
      `<p>Configure how often to take snapshots and how long to retain them.</p><div class="retention-head"><b>TAKE SNAPSHOTS</b><b>RETAIN SNAPSHOTS</b></div><div class="frequency-rows">${['hours','days','weeks','months','years',...(x.showMore?['minutes']:[])].map(unit=>`<div class="frequency-row"><span>Every</span><input type="number" min="0" name="freq-${unit}" placeholder="—" value="${esc(x.frequency?.[unit]??'')}"><span>${unit}(s)</span><span>For</span><input type="number" min="0" name="ret-${unit}" placeholder="—" value="${esc(x.retention?.[unit]??'')}"><select name="ret-unit-${unit}" aria-label="Retention unit for ${unit}"><option ${(!x.retentionUnit||x.retentionUnit[unit]==='days')?'selected':''}>days</option><option ${x.retentionUnit?.[unit]==='weeks'?'selected':''}>weeks</option><option ${x.retentionUnit?.[unit]==='months'?'selected':''}>months</option><option ${x.retentionUnit?.[unit]==='years'?'selected':''}>years</option></select></div>`).join('')}</div><button class="btn small" id="show-more">${x.showMore?'SHOW LESS':'＋ SHOW MORE'}</button><div class="toggle-heading"><h3>SNAPSHOT WINDOWS</h3><label class="switch"><input id="snapshot-windows" type="checkbox" ${x.snapshotWindows?'checked':''}><span></span></label></div>${x.snapshotWindows?'<div class="field"><label>WINDOW START TIME</label><input type="time" id="window-start" value="'+esc(x.windowStart||'00:00')+'"></div>':''}`,
      `<p class="schedule-summary">Selected snapshot schedule: <b>${esc(frequencySummary)}</b><br>Retention: <b>${esc(retentionSummary)}</b></p><div class="card"><label class="check-row"><input id="archival-enabled" type="checkbox" ${x.archival?'checked':''}> <b>Archival</b></label><p>Make sure there are archival locations for data center and cloud objects in RSC before configuring archival.</p></div><div class="card"><label class="check-row"><input id="replication-enabled" type="checkbox" ${x.replication!==false?'checked':''}> <b>Replication</b></label><p>For data center objects, make sure replication pairings exist between the replication source and target, then select the mode.</p><label class="check-row"><input type="radio" name="replication-mode" value="Many-to-one" ${x.replicationMode==='Many-to-one'?'checked':''}> <span><b>Many-to-one</b><br>Configure only replication targets. The source is selected when you assign an SLA Domain.</span></label><label class="check-row"><input type="radio" name="replication-mode" value="One-to-one" ${(x.replicationMode||'One-to-one')==='One-to-one'?'checked':''}> <span><b>One-to-one</b><br>Configure the replication source and target.</span></label><p class="subtle">Replication pair: ${esc(state.policy?.source||'—')} ↔ ${esc(state.policy?.target||'—')}</p></div>`,
      `<p class="schedule-summary"><b>Source retention</b><br>Snapshots remain in local storage for <b>${archiveYears} year(s), ${archiveRemainder} day(s)</b>.</p><div class="range-line source-retention-range"><span>0 days</span><input id="archival-retention" type="range" min="0" max="365" value="${archiveDays}" aria-label="Source retention in days"><b><span id="archival-retention-value">${archiveDays} days</span></b><span>1 year</span></div><div class="card archival-policy-card"><h3>ARCHIVAL POLICY 1</h3><p>All archival locations in a policy must be the same type.</p><p class="subtle">Only archival locations included in the selected HA Policy are available here.</p>${x.archival?archiveClusters.map(cluster=>`<div class="field"><label>FOR ${esc(cluster.toUpperCase())} DATA CENTER OBJECTS</label><select name="archive-cluster" data-cluster="${esc(cluster)}"><option value="">Select archival location</option>${archiveOptions.map(location=>`<option value="${esc(location)}" ${archiveSelections[cluster]===location?'selected':''}>${esc(location)}</option>`).join('')}</select></div>`).join('')||'<p class="notice">No archival locations were selected in the HA Policy.</p>':'<p class="notice">Enable Archival on the previous step to configure archival locations.</p>'}</div>`,
      `<p class="schedule-summary"><b>Selected snapshot schedule</b><br>Frequency: ${esc(frequencySummary)}<br>Retention: ${esc(retentionSummary)}</p><div class="field"><label>LOCAL STORAGE RETENTION</label><p class="subtle">When replication retention is reached, keep snapshots in local storage for this additional period.</p><div class="range-line"><span>0 days</span><input id="local-retention" type="range" min="0" max="${localRetentionMax}" value="${localRetentionInitial}" data-snapshot-retention-days="${retentionDays}" aria-label="Local storage retention in days"><b><span id="local-retention-value">${localRetentionInitial}</span> days</b><span>${localRetentionMax} days</span></div></div><div class="card"><h3>REPLICATION POLICY</h3><p>For data center objects · ${esc(x.replicationMode||'One-to-one')}</p><div class="replication-table"><b>REPLICATION SOURCE</b><b>REPLICATION TARGET</b><span>${esc(state.policy?.source||'—')}</span><span>${esc(state.policy?.target||'—')}</span>${x.replicationMode==='Many-to-one'?'<span>Source is chosen when assigning this SLA Domain</span><span>Target is configured here</span>':`<span>${esc(state.policy?.target||'—')}</span><span>${esc(state.policy?.source||'—')}</span>`}</div><label class="field"><span>REPLICATION RETENTION</span><div class="range-line"><span>0 days</span><input id="rep-retention" type="range" min="0" max="${replicationMax}" value="${replicationInitial}"><b><span id="rep-retention-value">${replicationInitial}</span> days</b></div></label></div>`,
      `<div class="field"><label>HA SLA DOMAIN NAME *</label><input id="slname" maxlength="255" placeholder="Enter an SLA Domain name" value="${esc(x.name||'')}"></div><div class="field"><label>DESCRIPTION <span class="muted">(optional)</span></label><textarea id="sldesc" placeholder="Enter a description">${esc(x.description||'')}</textarea></div><hr><h3>HA POLICY</h3><div class="summary"><b>HA Policy Name</b><span>${esc(state.policy?.name||'—')}</span><b>Source Cluster</b><span>${esc(state.policy?.source||'—')}</span><b>Target Cluster</b><span>${esc(state.policy?.target||'—')}</span><b>Selected workloads / hosts</b><span>${policyHosts.map(esc).join(', ')||'None selected'}</span></div><hr><h3>SLA DOMAIN CONFIGURATION</h3><div class="summary"><b>Object types</b><span>${(x.objects||[]).map(esc).join(', ')||'None selected'}</span><b>Snapshot frequency</b><span>${esc(frequencySummary)}</span><b>Snapshot retention</b><span>${esc(retentionSummary)}</span><b>Snapshot windows</b><span>${x.snapshotWindows?`Enabled · ${esc(x.windowStart||'')}`:'Disabled'}</span><b>Retention Lock</b><span>${x.retentionLock?'Enabled':'Disabled'}</span><b>Archival</b><span>${x.archival?'Enabled':'Disabled'}</span><b>Archival locations</b><span>${esc(archivePolicySummary)}</span><b>Source retention</b><span>${archiveDays} days</span><b>Replication</b><span>${x.replication===false?'Disabled':esc(x.replicationMode||'One-to-one')}</span><b>Local storage retention</b><span>${esc(x.localRetention??0)} days</span><b>Replication retention</b><span>${esc(x.repRetention??replicationInitial)} days</span></div>`
    ];
    const title=slaPages[n-1];
    screen.innerHTML=`<div class="step-dots">${slaPages.map((_,i)=>`<span class="${i<n?'on':''}"></span>`).join('')}</div><div class="subtle">STEP ${n} OF 9</div><div class="section-list"><article class="card sla-card"><h3>${title}</h3>${content[n-1]}</article></div><div class="actions"><button class="btn" id="sback" ${n===1?'disabled':''}>BACK</button>${n<9?'<button class="btn primary" id="snext">NEXT</button>':continueButton('CREATE',true)}</div>`;
    if(n===5){$('#show-more').onclick=()=>{readSla();state.sla.showMore=!state.sla.showMore;sla();};$('#snapshot-windows').onchange=()=>{readSla();state.sla.snapshotWindows=$('#snapshot-windows').checked;sla();};}
    if(n===6){$('#archival-enabled').onchange=()=>{readSla();state.sla.archival=$('#archival-enabled').checked;sla();};$('#replication-enabled').onchange=()=>{readSla();state.sla.replication=$('#replication-enabled').checked;persist();};document.querySelectorAll('[name="replication-mode"]').forEach(el=>el.onchange=()=>{readSla();state.sla.replicationMode=el.value;persist();});}
    if(n===3)$('#mapped').onchange=()=>{readSla();sla();};
    if(n===7)$('#archival-retention').oninput=()=>{$('#archival-retention-value').textContent=`${$('#archival-retention').value} days`;};
    if(n===8){$('#local-retention').oninput=()=>$('#local-retention-value').textContent=`${$('#local-retention').value} days`;$('#rep-retention').oninput=()=>$('#rep-retention-value').textContent=$('#rep-retention').value;}
    document.querySelectorAll('[name="archive-cluster"]').forEach(el=>el.onchange=()=>{readSla();persist();});
    $('#sback').onclick=()=>{readSla();state.slaPage=Math.max(1,n-1);persist();sla();};
    if(n<9)$('#snext').onclick=()=>{
      readSla();
      if(n===2&&!(state.sla.objects||[]).length){error('Select at least one supported object type.');return;}
      if(n===2&&!(state.sla.objects||[]).includes('vSphere VMs')){error('Select vSphere VMs for the VMware workload mission. You may also select other object types.');return;}
      if(n===3&&!state.sla.mapped){error('Select the HA Policy you created.');return;}
      if(n===5&&(!Object.values(state.sla.frequency||{}).some(v=>Number(v)>0)||!Object.values(state.sla.retention||{}).some(v=>Number(v)>0))){error('Enter at least one snapshot frequency and one retention value.');return;}
      if(n===6&&state.sla.replication!==false&&!state.sla.replicationMode){error('Choose a replication mode.');return;}
      if(n===7&&state.sla.archival&&archiveClusters.some(cluster=>!state.sla.archivalLocations?.[cluster])){error('Choose an archival location for each cluster, or turn off Archival on the previous step.');return;}
      state.slaPage=n+1;persist();sla();
      if(n>1)chef(({2:'Object type selection saved.',3:'HA Policy mapped. The source and target clusters are shown above.',4:'Retention Lock selection saved.',5:'Frequency and retention saved.',6:'Archival and replication choices saved.',7:'Archival parameters saved.',8:'Replication parameters saved. Review the full configuration before creating the SLA Domain.'})[n],'GRUMPY / IMPRESSED',n===8);
    };
    if(n===9){const c=screen.querySelector('[data-continue]');c.onclick=()=>{readSla();if(!state.sla.name){error('Enter an HA SLA Domain name before creating it.');return;}persist();state.step='protect';persist();chef('HA SLA Domain configured. Choose the VMware workloads that should receive this SLA Domain.','IMPRESSED');protect();};}
  }
  function readSla(){
    const x=state.sla||{}; const name=$('#slname')?.value.trim();
    const next={...x,name:name??x.name,description:$('#sldesc')?.value??x.description};
    if($('#mapped'))next.mapped=$('#mapped').value;
    if($('#system-tags'))next.systemTags=$('#system-tags').checked;
    if($('#retention-lock'))next.retentionLock=$('#retention-lock').checked;
    if($('#snapshot-windows')){next.snapshotWindows=$('#snapshot-windows').checked;next.windowStart=$('#window-start')?.value||x.windowStart;}
    if($('[name="freq-hours"]')){next.frequency={};next.retention={};next.retentionUnit={};for(const u of ['hours','days','weeks','months','years','minutes']){const f=$(`[name="freq-${u}"]`),r=$(`[name="ret-${u}"]`),unit=$(`[name="ret-unit-${u}"]`);if(f)next.frequency[u]=f.value;if(r)next.retention[u]=r.value;if(unit)next.retentionUnit[u]=unit.value;}next.showMore=!!$('[name="freq-minutes"]');}
    if($('#archival-enabled'))next.archival=$('#archival-enabled').checked;
    if($('#sla-archive'))next.archiveLocation=$('#sla-archive').value;
    if($('#archival-retention'))next.archivalRetentionDays=Number($('#archival-retention').value);
    if(document.querySelectorAll('[name="archive-cluster"]').length){next.archivalLocations={};document.querySelectorAll('[name="archive-cluster"]').forEach(el=>next.archivalLocations[el.dataset.cluster]=el.value);}
    if($('#replication-enabled'))next.replication=$('#replication-enabled').checked;
    const mode=document.querySelector('[name="replication-mode"]:checked');if(mode)next.replicationMode=mode.value;
    if($('#local-retention')){next.localRetention=Number($('#local-retention').value);next.localRetentionForRetentionDays=Number($('#local-retention').dataset.snapshotRetentionDays);}
    if($('#rep-retention'))next.repRetention=Number($('#rep-retention').value);
    if(document.querySelectorAll('[name="objects"]').length)next.objects=selected('objects');
    if($('#detailed'))next.detailed=x.detailed;
    state.sla=next;persist();
  }
  function protect(){
    chrome('Protect VMware workload','VMWARE PROTECTION');
    const vmInventory=[
      ['FINANCE-APP-01','Powered on · 4 vCPU · 16 GB'],
      ['HR-PORTAL-02','Powered on · 2 vCPU · 8 GB'],
      ['ENG-BUILD-03','Powered on · 8 vCPU · 32 GB'],
      ['PAYROLL-DB-01','Powered on · 4 vCPU · 16 GB']
    ];
    const chosen=new Set(state.sla?.workloads||[]);
    const availableSlaDomains=[...new Set([...(state.sla?.availableDomains||[]),state.sla?.name].filter(name=>typeof name==='string'&&name.trim()))];
    const selectedSlaDomain=state.sla?.assignedDomain||state.sla?.name||'';
    const vmTypeSelected=(state.sla?.objects||[]).includes('vSphere VMs');
    screen.innerHTML=`<div class="notice"><b>INVENTORY · ${esc(state.policy?.source||'NORTH CLUSTER')}</b><br>Select one or more VMware workloads for the SLA Domain. Replication target: ${esc(state.policy?.target||'South')}.</div><div class="grid"><article class="card"><h3>VMWARE VIRTUAL MACHINES · SELECT WORKLOADS</h3><p class="subtle">RUBSIM sample inventory · choose every VM that should receive this SLA Domain.</p>${vmInventory.map(([name,details])=>`<label class="check-row workload-option"><input type="checkbox" name="workload-selection" value="${esc(name)}" ${chosen.has(name)?'checked':''} ${vmTypeSelected?'':'disabled'}><span>${esc(name)} <small class="muted">· ${esc(details)}</small></span></label>`).join('')}<p>Cluster: ${esc(state.policy?.source||'North')}</p>${vmTypeSelected?'':'<p class="notice alert">Select vSphere VMs in the SLA Domain object types to protect VMware workloads.</p>'}</article><article class="card"><h3>ASSIGN SLA DOMAIN</h3><div class="field"><label>SELECT SLA</label><select id="vm-sla" ${availableSlaDomains.length?'':'disabled'}><option value="">Select an SLA Domain</option>${availableSlaDomains.map(name=>`<option value="${esc(name)}" ${selectedSlaDomain===name?'selected':''}>${esc(name)}</option>`).join('')}</select></div><p>Mapped HA Policy: ${esc(state.policy?.name||'—')}</p><p>Replication target: ${esc(state.policy?.target||'South')}</p></article></div><div class="actions"><button class="btn primary" id="protect-btn">ASSIGN & PROTECT</button></div>`;
    $('#vm-sla').onchange=()=>{state.sla={...state.sla,assignedDomain:$('#vm-sla').value};persist();};
    $('#protect-btn').onclick=()=>{
      const workloads=[...new Set(selected('workload-selection'))];
      if(!workloads.length){error(vmTypeSelected?'Select at least one VMware workload.':'This SLA Domain does not include vSphere VMs.');return;}
      const assignedDomain=$('#vm-sla').value;
      if(!assignedDomain){error('Select an available HA SLA Domain before assigning workloads.');return;}
      state.sla={...state.sla,assignedDomain,workloads};state.step='disaster';persist();
      chef(`The SLA Domain ${assignedDomain} is assigned to ${workloads.join(', ')}. Snapshots are replicating to ${state.policy?.target||'South'}.`,'IMPRESSED');
      screen.innerHTML=`<div class="notice"><b>PROTECTION VERIFIED</b><br>${workloads.map(esc).join(', ')} · SLA ${esc(assignedDomain)} · Latest snapshots replicated to ${esc(state.policy?.target||'South')}.</div><div class="actions"><button class="btn primary continue-ready" id="incident">CONTINUE TO INCIDENT</button></div>`;$('#incident').onclick=disaster;
    };
  }
  function snapshotCadence(){
    const values=state.sla?.frequency||{};const active=Object.entries(values).filter(([,v])=>String(v||'').length);
    return active.map(([unit,v])=>`every ${v} ${unit}`).join(', ')||'the configured schedule';
  }
  function protectedWorkloads(){return [...new Set(state.sla?.workloads||[])];}
  function disaster(){
    state.step='disaster';persist();chrome('Godzilla attacks Data Center North','CATASTROPHE CUTSCENE');
    if(!Number.isInteger(state.catastropheIndex))state.catastropheIndex=0;
    renderCatastrophe();
  }
  function renderCatastrophe(){
    const beats=[
      {scene:'approach',speaker:'SYSTEM ALERT',text:'A tremor shakes the valley. Godzilla climbs out of the volcano and stops in front of Data Center North.',manager:false,player:false},
      {scene:'manager',speaker:'THE BOSS',text:'How could you miss this?',manager:true,player:true,expression:'startled'},
      {scene:'player',speaker:state.operator||'YOU',text:'How was I supposed to know this?',manager:true,player:true,expression:'indignant'},
      {scene:'attack',speaker:'SYSTEM ALERT',text:'Godzilla opens his jaws and unleashes a torrent of fire from his mouth. Data Center North erupts in flames and explodes!',manager:false,player:false},
      {scene:'resolve',speaker:state.operator||'YOU',text:'I have configured High Availability and HA SLA Domains. Our data is replicated, and we can initiate a failover.',manager:true,player:true,expression:'confident'}
    ];
    const beat=beats[state.catastropheIndex];
    const names=protectedWorkloads().map(esc).join(', ')||'Protected VMware workloads';
    const managerSprite=beat.scene==='manager'?'manager-yelling-pixel.png':'manager-full-pixel.png';
    screen.innerHTML=`<div class="catastrophe-stage" data-cutscene="${beat.scene}" role="group" aria-label="Godzilla approaches and attacks Data Center North"><div class="cutscene-haze"></div><div class="volcano-glow"></div><div class="data-center-sign">DATA CENTER NORTH</div><img class="kaiju-sprite" src="assets/godzilla-pixel.png" alt="Godzilla"><img class="fire-breath" src="assets/godzilla-fire-right-pixel.png" alt="" aria-hidden="true"><div class="data-center-explosion" aria-hidden="true"></div>${beat.manager?`<img class="cutscene-manager" src="assets/${managerSprite}" alt="The boss">`:''}${beat.player?`<img class="cutscene-seated-player" src="assets/player-seated-pixel.png" alt="${esc(state.operator||'Player')} seated at the desk"><svg class="player-expression ${beat.expression||''}" viewBox="0 0 100 60" aria-hidden="true"><path class="brow brow-left" d="M18 15h24v5H18z"/><path class="brow brow-right" d="M59 15h23v5H59z"/><path class="mouth" d="M39 42h24v7H39z"/></svg>`:''}<div class="cutscene-dialogue"><div><small>${esc(beat.speaker)}</small><p>${esc(beat.text)}</p><span class="cutscene-workloads">PROTECTED: ${names}</span></div><button class="btn primary" id="cutscene-next">${state.catastropheIndex===beats.length-1?'CONTINUE TO FAILOVER':'NEXT SCENE'}</button></div><div class="cutscene-counter">SCENE ${state.catastropheIndex+1} / ${beats.length}</div></div>`;
    $('#cutscene-next').onclick=()=>{if(state.catastropheIndex<beats.length-1){state.catastropheIndex++;renderCatastrophe();}else{state.catastropheIndex=0;failover();}};
  }
  function failover(){
    state.step='failover';persist();chrome('High Availability Policies','RECOVERY OPERATIONS');
    if(state.failoverStage==='policy')renderFailoverPolicies();
    else if(state.failoverStage==='readiness')renderFailoverReadiness();
    else if(state.failoverStage==='method')renderFailoverMethod();
    else if(state.failoverStage==='details')renderFailoverDetails();
    else if(state.failoverStage==='confirm')renderFailoverConfirm();
    else if(state.failoverStage==='progress')renderFailoverProgress();
    else renderFailoverComplete();
  }
  function failoverContext(){
    return {policy:state.policy||{name:'HA Policy',source:'North',target:'South',hosts:[],archives:[]},source:state.policy?.source||'North',target:state.policy?.target||'South',hosts:[...new Set(state.policy?.hosts||[])],workloads:protectedWorkloads(),archives:[...new Set(state.policy?.archives||[])],sla:state.sla?.name||'HA SLA Domain'};
  }
  function failoverDots(active){
    return `<div class="failover-wizard-dots">${['POLICY','READINESS','METHOD','DETAILS','START','EVENTS'].map((label,i)=>`<span class="${i<=active?'on':''}"><b>${i+1}</b><small>${label}</small></span>`).join('')}</div>`;
  }
  function failoverActions(backId,nextId,nextLabel='NEXT'){
    return `<div class="actions"><button class="btn" id="${backId}">BACK</button><button class="btn primary" id="${nextId}">${nextLabel}</button></div>`;
  }
  function renderFailoverPolicies(){
    const c=failoverContext(); const hostCount=c.hosts.length; const workloadCount=c.workloads.length;
    screen.innerHTML=`<div class="ha-policy-page"><div class="failover-page-toolbar"><span class="eyebrow">SETTINGS / HIGH AVAILABILITY</span><button class="btn primary" disabled>CREATE HA POLICY</button></div><h2>High Availability Policies</h2><div class="policy-list-filters"><span>STATUS</span><span class="tag ok">Active / Ready</span><span class="subtle">Source: ${esc(c.source)} · Target: ${esc(c.target)}</span></div><div class="table-wrap failover-policy-table"><table><thead><tr><th>HA POLICY</th><th>CURRENT SOURCE CLUSTER</th><th>CURRENT TARGET CLUSTER</th><th>HOSTS</th><th>OBJECTS</th><th>ARCHIVAL LOCATIONS</th><th>FAILOVER STATUS</th><th></th></tr></thead><tbody><tr><td><b>${esc(c.policy.name||'HA Policy')}</b></td><td>${esc(c.source)}</td><td>${esc(c.target)}</td><td>${hostCount}</td><td>${workloadCount}</td><td>${c.archives.length}</td><td><span class="tag ok">Active / Ready</span></td><td><button class="btn small" id="failover-menu" aria-expanded="false" aria-controls="failover-menu-items" aria-label="Open HA Policy actions">•••</button></td></tr></tbody></table></div><div id="failover-menu-items" class="failover-menu hidden"><button class="btn" id="start-failover">Start Failover</button><button class="btn" disabled>Edit Policy</button></div><div class="failover-context-note"><b>INCIDENT</b><span>Data Center ${esc(c.source)} is unavailable after the Godzilla attack. Start a manual failover to move backup and recovery operations to ${esc(c.target)}.</span></div><p class="subtle">A manual failover transfers the HA Policy role. It does not start the protected VMs as production workloads.</p></div>`;
    $('#failover-menu').onclick=()=>{const button=$('#failover-menu');const menu=$('#failover-menu-items');const open=menu.classList.toggle('hidden')===false;button.setAttribute('aria-expanded',String(open));if(open){const rect=button.getBoundingClientRect();const parent=$('.ha-policy-page').getBoundingClientRect();menu.style.left=`${Math.max(8,rect.right-parent.left-menu.offsetWidth)}px`;menu.style.top=`${rect.bottom-parent.top+5}px`;}};
    $('#start-failover').onclick=()=>{state.failoverStage='readiness';state.failoverEvent=0;state.failoverAcknowledged=false;persist();renderFailoverReadiness();};
  }
  function renderFailoverReadiness(){
    const c=failoverContext(); const objectRows=c.workloads.length?c.workloads.map(name=>`<tr><td>Protected workload</td><td>${esc(name)}</td><td><span class="tag ok">READY</span></td></tr>`).join(''):`<tr><td>Protected workloads</td><td>No workload names recorded</td><td><span class="tag">REVIEW</span></td></tr>`;
    const hostStatus=c.hosts.length?`${c.hosts.length} selected host(s) are included in the policy.`:'No standalone RBS hosts were selected; the protected VM objects are listed below.';
    const archiveStatus=c.archives.length?`${c.archives.map(esc).join(', ')} · configured in the policy.`:'No archival locations are configured in this policy.';
    chrome('Review failover readiness','START FAILOVER · STEP 1 OF 4');
    screen.innerHTML=`${failoverDots(1)}<article class="card failover-wizard-card"><h2>Review failover readiness</h2><p class="subtle">Review the hosts, protected workloads, and archival locations in the HA Policy. Resolve warnings before continuing.</p><div class="summary failover-pair"><b>HA Policy</b><span>${esc(c.policy.name||'HA Policy')}</span><b>Current primary</b><span>${esc(c.source)} · UNAVAILABLE</span><b>Failover target</b><span>${esc(c.target)}</span></div><div class="table-wrap readiness-table"><table><thead><tr><th>TYPE</th><th>POLICY OBJECT</th><th>READINESS</th></tr></thead><tbody><tr><td>Hosts</td><td>${esc(hostStatus)}</td><td><span class="tag ok">READY</span></td></tr>${objectRows}<tr><td>Archival locations</td><td>${archiveStatus}</td><td><span class="tag ${c.archives.length?'ok':''}">${c.archives.length?'READY':'NOT CONFIGURED'}</span></td></tr></tbody></table></div><div class="notice alert"><b>PRIMARY CLUSTER UNREACHABLE</b><br>Clean failover is unavailable. The forced failover path will use the latest snapshots that reached ${esc(c.target)}.</div></article>${failoverActions('failover-readiness-back','failover-readiness-next')}`;
    $('#failover-readiness-back').onclick=()=>{state.failoverStage='policy';persist();failover();};
    $('#failover-readiness-next').onclick=()=>{state.failoverStage='method';persist();failover();};
  }
  function renderFailoverMethod(){
    const c=failoverContext();
    chrome('Select failover method','START FAILOVER · STEP 2 OF 4');
    screen.innerHTML=`${failoverDots(2)}<article class="card failover-wizard-card"><h2>Select a failover method</h2><p class="subtle">Choose how RSC should transfer this HA Policy. Clean Failover is only available when the primary cluster is reachable.</p><label class="failover-method-card disabled"><input type="radio" name="failover-method" value="clean" disabled><span><b>Clean Failover</b><small>Gracefully pauses backups on ${esc(c.source)} and waits for pending snapshots to replicate before the transition.</small><em>Unavailable · ${esc(c.source)} cannot be reached</em></span></label><label class="failover-method-card selected"><input type="radio" name="failover-method" value="forced" checked><span><b>Forced Failover</b><small>Best-effort disaster recovery using the latest available data on ${esc(c.target)}. It does not wait for the replication queue to drain.</small><em>Available for this incident</em></span></label><div class="notice alert"><b>DATA-LOSS RISK</b><br>Snapshots that had not replicated or uploaded before ${esc(c.source)} became unavailable may be missing on ${esc(c.target)}. The original primary’s unreplicated snapshots remain unavailable until it returns.</div><label class="check-row failover-ack"><input type="checkbox" id="failover-ack" ${state.failoverAcknowledged?'checked':''}> I acknowledge the data-loss risk of forced failover.</label></article>${failoverActions('failover-method-back','failover-method-next')}`;
    $('#failover-ack').onchange=()=>{state.failoverAcknowledged=$('#failover-ack').checked;persist();};
    $('#failover-method-back').onclick=()=>{state.failoverStage='readiness';persist();failover();};
    $('#failover-method-next').onclick=()=>{state.failoverAcknowledged=$('#failover-ack').checked;if(!state.failoverAcknowledged){error('Acknowledge the forced failover data-loss risk before continuing.');return;}state.failoverStage='details';persist();failover();};
  }
  function renderFailoverDetails(){
    const c=failoverContext();
    chrome('Review failover details','START FAILOVER · STEP 3 OF 4');
    screen.innerHTML=`${failoverDots(3)}<article class="card failover-wizard-card"><h2>Review failover details</h2><p>Confirm the HA Policy transition before you start it.</p><div class="summary failover-details-summary"><b>HA Policy</b><span>${esc(c.policy.name||'HA Policy')}</span><b>Failover method</b><span>Forced Failover</span><b>Current primary</b><span>${esc(c.source)} · unavailable</span><b>New primary</b><span>${esc(c.target)}</span><b>Protected workloads</b><span>${c.workloads.map(esc).join(', ')||'None recorded'}</span><b>Snapshot schedule</b><span>${esc(snapshotCadence())}</span><b>Archival locations</b><span>${c.archives.map(esc).join(', ')||'None configured'}</span><b>Data consistency</b><span>Use latest snapshots replicated to ${esc(c.target)}</span></div><div class="failover-sequence"><h3>AFTER START</h3><ol><li>Transfer archival ownership to ${esc(c.target)} where archival is configured.</li><li>Update host services and promote protected objects on ${esc(c.target)}.</li><li>Resume incremental backups and archival uploads using the existing chains.</li><li>Replicate new snapshots back to ${esc(c.source)} if it becomes available.</li></ol></div><p class="subtle">Forced failover proceeds without waiting for pending replication. Data not present on ${esc(c.target)} cannot be recovered in this step.</p></article>${failoverActions('failover-details-back','failover-details-next')}`;
    $('#failover-details-back').onclick=()=>{state.failoverStage='method';persist();failover();};
    $('#failover-details-next').onclick=()=>{state.failoverStage='confirm';persist();failover();};
  }
  function renderFailoverConfirm(){
    const c=failoverContext();
    chrome('Start failover','START FAILOVER · FINAL CONFIRMATION');
    screen.innerHTML=`${failoverDots(4)}<article class="card failover-wizard-card"><div class="eyebrow">FINAL CHECK</div><h2>Start forced failover?</h2><p>This starts the manual transfer for <b>${esc(c.policy.name||'HA Policy')}</b>.</p><div class="summary failover-pair"><b>From</b><span>${esc(c.source)} · unavailable</span><b>To</b><span>${esc(c.target)} · will become primary</span><b>Method</b><span>Forced Failover</span></div><div class="notice alert"><b>ACKNOWLEDGED RISK</b><br>The transition uses the latest replicated snapshots on ${esc(c.target)}. Changes that never reached the target may be lost.</div></article><div class="actions"><button class="btn" id="failover-confirm-back">BACK</button><button class="btn primary" id="failover-start-confirmed">START FAILOVER</button></div>`;
    $('#failover-confirm-back').onclick=()=>{state.failoverStage='details';persist();failover();};
    $('#failover-start-confirmed').onclick=()=>{state.failoverStage='progress';state.failoverEvent=0;persist();failover();};
  }
  function renderFailoverProgress(){
    const c=failoverContext(); const events=[
      {title:`Confirm ${c.source} is unavailable`,detail:'Forced mode skips the clean-failover replication queue drain and uses the latest data on the secondary.'},
      {title:'Transfer archival ownership',detail:c.archives.length?`${c.archives.map(esc).join(', ')} become owned by ${esc(c.target)}.`:'No archival locations are configured; this event is not applicable.'},
      {title:'Update host services and promote objects',detail:`RBS registrations and protected objects move to ${esc(c.target)}.`},
      {title:'Resume backup and archival operations',detail:`${c.target} continues the existing snapshot chain and uploads to the same archive where configured.`},
      {title:'Set the new primary cluster',detail:`${c.target} is now primary. Replication back to ${esc(c.source)} can resume when it is available.`}
    ];
    const n=Math.min(state.failoverEvent,events.length);
    chrome('Failover events','HA POLICY EVENTS · FAILOVER IN PROGRESS');
    screen.innerHTML=`${failoverDots(5)}<article class="card failover-wizard-card"><div class="failover-event-heading"><div><div class="eyebrow">${esc(c.policy.name||'HA POLICY')}</div><h2>Failover progress</h2></div><span class="tag ${n===events.length?'ok':'warn'}">${n===events.length?'FAILOVER COMPLETED':'FAILOVER IN PROGRESS'}</span></div><div class="failover-progress"><span style="width:${Math.round(n/events.length*100)}%"></span></div><div class="failover-events-list">${events.map((event,i)=>`<article class="failover-event ${i<n?'done':i===n?'current':''}"><span class="event-mark">${i<n?'✓':i===n?'●':'○'}</span><div><b>${esc(event.title)}</b><p>${event.detail}</p></div><small>${i<n?'COMPLETE':i===n?'IN PROGRESS':'PENDING'}</small></article>`).join('')}</div><div class="schedule-summary"><b>EVENT MONITORING</b><br>In RSC, track this transition from the HA Policy Events page. If an individual host or workload does not complete, the operation is retried periodically and its status remains available in the events view.</div></article><div class="actions">${n<events.length?'<button class="btn primary" id="advance-failover-event">ADVANCE EVENT</button>':'<button class="btn primary" id="finish-failover-events">VIEW COMPLETED FAILOVER</button>'}</div>`;
    $('#advance-failover-event')?.addEventListener('click',()=>{state.failoverEvent=Math.min(state.failoverEvent+1,events.length);if(state.failoverEvent===events.length)state.failoverStage='complete';persist();failover();});
    $('#finish-failover-events')?.addEventListener('click',()=>{state.failoverStage='complete';persist();failover();});
  }
  function renderFailoverComplete(){
    const c=failoverContext();
    chrome('Failover completed','HA POLICY · ACTIVE ON SECONDARY');
    screen.innerHTML=`<article class="card failover-wizard-card failover-complete"><div class="eyebrow">FAILOVER COMPLETED</div><h2>${esc(c.target)} is the new primary cluster</h2><div class="summary failover-pair"><b>HA Policy</b><span>${esc(c.policy.name||'HA Policy')}</span><b>Previous primary</b><span>${esc(c.source)} · unavailable</span><b>Current primary</b><span>${esc(c.target)} · Active / Ready</span><b>Protected workloads</b><span>${c.workloads.map(esc).join(', ')||'No workload names recorded'}</span><b>Recovery point</b><span>Latest snapshots replicated to ${esc(c.target)}</span></div><p>Incremental backups continue on the existing snapshot chain. Archival uploads resume to the same locations where configured.</p><div class="notice"><b>NEXT TASK · FAILBACK</b><br>After ${esc(c.source)} has recovered and is reachable—and any forced-failover reconciliation is complete—perform a clean failback to restore the original primary role.</div><button class="btn primary" id="finish-failover">CONTINUE</button></article>`;
    $('#finish-failover').onclick=()=>{state.step='ending';state.endingStage='talk';persist();ending();};
  }
  function ending(){
    if(state.endingStage==='talk'){
      chrome('A word from the boss','MISSION WRAP-UP');
      screen.innerHTML=`<div class="adventure-scene office-scene ending-scene" role="group" aria-label="The player and boss stand face to face in the office"><div class="scene-shade"></div><figure class="ending-actor ending-player"><img src="assets/player-pixel.png" alt="${esc(state.operator||'Player')}"><figcaption>${esc(state.operator||'Player')}</figcaption></figure><figure class="ending-actor ending-boss"><img src="assets/manager-full-pixel.png" alt="The Boss"><figcaption>THE BOSS</figcaption></figure><div class="ending-dialogue"><small>THE BOSS · GRUMPY</small><p>You were able to get us out of this mess this time, but who knows what will happen next?</p><button class="btn primary" id="ending-next">NEXT</button></div></div>`;
      $('#ending-next').onclick=()=>{state.endingStage='eyes';persist();ending();};
      return;
    }
    if(state.endingStage==='eyes'){
      chrome('Signal detected','UNKNOWN PRESENCE');
      screen.innerHTML=`<div class="eyes-console" role="img" aria-label="A pair of eyes blink in the darkness"><div class="console-eyes"><i></i><i></i></div><p>Something is still out there.</p><button class="btn primary" id="ending-next">CONTINUE</button></div>`;
      $('#ending-next').onclick=()=>{state.endingStage='complete';persist();ending();};
      return;
    }
    state.step='done';persist();done();
  }
  function done(){
    chrome('Well done!','MISSION COMPLETE');
    const names=protectedWorkloads().map(esc).join(', ')||'No VMware workloads assigned';
    const source=esc(state.policy?.source||'North'),target=esc(state.policy?.target||'South');
    screen.innerHTML=`<div class="notice"><b>WELL DONE!</b><br>You successfully protected ${names} with the ${esc(state.sla?.assignedDomain||state.sla?.name||'HA SLA Domain')} and completed failover to ${target}. Backup operations are continuing on the secondary cluster.</div><p>Both clusters upgraded to CDM 9.6 · HA Policy and HA SLA Domain configured · High Availability failover completed.</p><div class="grid"><article class="card"><h3>HA POLICY</h3><p>${esc(state.policy?.name||'—')} · ${source} → ${target}</p></article><article class="card"><h3>RECOVERY</h3><p>${target} is the new primary, continuing the existing snapshot chain and archival uploads.</p><p class="subtle">Perform a clean failback after ${source} has recovered and reconciliation is complete.</p></article></div>`;
  }
  switch(state.step){case'intro':intro();break;case'arrival':arrival();break;case'conference':conference();break;case'quiz':renderQuiz();break;case'release':releaseNotes();break;case'upgrade':upgrade();break;case'policy':policy();break;case'sla':sla();break;case'protect':protect();break;case'disaster':disaster();break;case'failover':failover();break;case'ending':ending();break;default:done();}
})();
