(() => {
  const toggle = document.querySelector('#music-toggle');
  const volume = document.querySelector('#music-volume');
  const savedMute = localStorage.getItem('rubsimMusicMuted');
  const savedVolume = localStorage.getItem('rubsimMusicVolume');
  let muted = savedMute === 'true';
  let level = savedVolume !== null && Number.isFinite(Number(savedVolume)) ? Math.max(0, Math.min(100, Number(savedVolume))) : 35;
  let context = null, master = null, timer = null, nextTime = 0, beat = 0;
  let currentScene = 'office', activeCue = '', started = false;

  const cues = {
    office: { tempo:.625, lead:[67,null,70,null,74,null,70,67,65,null,67,null,70,null,62,null,67,null,70,74,77,null,74,70,65,null,69,null,72,70,65,null], bass:[43,null,null,null,50,null,null,null,41,null,null,null,48,null,null,null], chord:[55,58,62,58,53,57,60,57] },
    conference: { tempo:.556, lead:[62,null,65,69,null,65,64,null,62,null,65,69,null,72,69,null,60,null,64,67,null,64,62,null,60,null,64,67,null,71,67,null], bass:[38,null,null,null,45,null,null,null,36,null,null,null,43,null,null,null], chord:[50,53,57,53,48,52,55,52] },
    setup: { tempo:.5, lead:[72,null,76,79,null,76,74,null,72,null,76,79,83,null,79,null,67,null,71,74,null,71,69,null,67,null,71,74,79,null,74,null], bass:[36,null,null,null,43,null,null,null,33,null,null,null,40,null,null,null], chord:[48,52,55,52,45,48,52,48] },
    catastrophe: { tempo:.833, lead:[48,null,null,51,null,null,55,null,53,null,null,50,null,null,46,null,48,null,null,55,null,null,58,null,57,null,null,53,null,null,46,null], bass:[24,null,null,null,24,null,null,null,31,null,null,null,29,null,null,null], chord:[36,null,39,null,43,null,39,null,34,null,38,null,41,null,38,null] },
    failover: { tempo:.545, lead:[62,null,65,null,69,67,null,65,64,null,67,null,72,69,null,null,62,null,65,null,69,72,null,74,72,null,69,null,67,65,62,null], bass:[38,null,null,null,38,null,null,null,33,null,null,null,40,null,null,null], chord:[50,53,57,53,45,48,52,48] },
    victory: { tempo:.5, lead:[72,null,76,79,84,null,79,null,77,null,81,84,89,null,84,null,79,null,83,86,91,null,86,null,84,null,88,91,96,null,91,null], bass:[36,null,null,null,43,null,null,null,41,null,null,null,48,null,null,null], chord:[48,52,55,60,55,52,53,57] }
  };
  const midiHz = note => 440 * Math.pow(2, (note - 69) / 12);
  const themeFor = (step, endingStage) => {
    if (step === 'conference' || step === 'quiz') return 'conference';
    if (step === 'release' || step === 'upgrade' || step === 'policy' || step === 'sla' || step === 'protect') return 'setup';
    if (step === 'disaster') return 'catastrophe';
    if (step === 'failover') return 'failover';
    if (step === 'ending' && endingStage === 'eyes') return 'silence';
    if (step === 'done') return 'victory';
    return 'office';
  };
  function refreshControls() {
    if (!toggle || !volume) return;
    toggle.textContent = muted ? '♫ MUSIC OFF' : '♫ MUSIC ON';
    toggle.setAttribute('aria-pressed', String(!muted));
    toggle.title = muted ? 'Turn the music on' : 'Mute the music';
    volume.value = String(level);
    volume.setAttribute('aria-valuetext', `${level}%`);
  }
  function ensureAudio() {
    if (!context) {
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) return false;
      context = new Audio();
      master = context.createGain();
      master.gain.value = 0;
      master.connect(context.destination);
    }
    if (context.state === 'suspended') context.resume();
    started = true;
    if (!timer) { nextTime = context.currentTime + .08; timer = window.setInterval(schedule, 40); }
    updateGain(.7);
    return true;
  }
  function updateGain(fade=.35) {
    if (!master || !context) return;
    const target = muted || level === 0 || activeCue === 'silence' || document.hidden ? 0 : (level / 100) * .32;
    master.gain.cancelScheduledValues(context.currentTime);
    master.gain.setTargetAtTime(target, context.currentTime, fade);
  }
  function playNote(note, time, duration, type, loudness) {
    if (note == null || !context || !master) return;
    const oscillator = context.createOscillator();
    const envelope = context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(midiHz(note), time);
    envelope.gain.setValueAtTime(.0001, time);
    envelope.gain.linearRampToValueAtTime(loudness, time + .018);
    envelope.gain.setTargetAtTime(.0001, time + duration * .62, Math.max(.025, duration * .16));
    oscillator.connect(envelope); envelope.connect(master);
    oscillator.start(time); oscillator.stop(time + duration + .16);
    oscillator.onended = () => { oscillator.disconnect(); envelope.disconnect(); };
  }
  function schedule() {
    if (!context || !started) return;
    const cue = cues[activeCue] || cues.office;
    while (nextTime < context.currentTime + .16) {
      const i = beat % cue.lead.length;
      if (!muted && activeCue !== 'silence' && !document.hidden) {
        playNote(cue.lead[i], nextTime, cue.tempo * .72, 'square', .24);
        if (beat % 2 === 0) playNote(cue.chord[(beat >> 1) % cue.chord.length], nextTime, cue.tempo * .42, 'triangle', .13);
        if (beat % 4 === 0) playNote(cue.bass[(beat >> 2) % cue.bass.length], nextTime, cue.tempo * 1.35, 'triangle', .3);
      }
      nextTime += cue.tempo;
      beat++;
    }
  }
  function setScene(step, endingStage) {
    const next = themeFor(step, endingStage);
    if (next === activeCue) return;
    activeCue = next; beat = 0;
    if (context) { nextTime = context.currentTime + .12; updateGain(.8); }
  }

  toggle?.addEventListener('click', () => {
    muted = !muted;
    localStorage.setItem('rubsimMusicMuted', String(muted));
    refreshControls();
    if (!muted) ensureAudio(); else updateGain(.25);
  });
  volume?.addEventListener('input', () => {
    level = Number(volume.value);
    localStorage.setItem('rubsimMusicVolume', String(level));
    if (!muted) ensureAudio();
    updateGain(.2); refreshControls();
  });
  document.addEventListener('click', () => { if (!muted) ensureAudio(); }, {capture:true});
  document.addEventListener('visibilitychange', () => { if (document.hidden) updateGain(.12); else if (!muted) { ensureAudio(); updateGain(.5); } });
  refreshControls();
  window.RUBSIMMusic = { setScene };
})();
